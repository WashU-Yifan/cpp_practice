#pragma once
class BaseClass {
    public:
        BaseClass();
        virtual ~BaseClass();
        virtual void nonVirtual();
};